#!/usr/bin/env bash
mvn clean package -P test -Dmaven.test.skip=true