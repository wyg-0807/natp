#!/usr/bin/env bash
mvn clean package -P dev